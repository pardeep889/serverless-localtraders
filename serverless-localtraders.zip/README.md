## BACKEND  APIS

## Getting started

Each service has its own README.md that describes the functions, request and its responses.

In order to run the services locally, `serverless-offline` plugin is required

### Offline Invocation

```sh
npm install
serverless offline
```

---
## SERVICES

### [wallet-service (WALLET API)](wallet-service/README.md)
